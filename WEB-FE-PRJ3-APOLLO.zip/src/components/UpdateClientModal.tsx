// components/UpdateClientModal.tsx
import React, { useState, useEffect } from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button } from '@mui/material';
import ClientForm from './ClientForm';
import Spinner from "./Spinner";
import ErrorComponent from './Error-component';
import { fetchClientById, updateClient } from '../services/createClient.service';
import { ListClientType } from '../types/ListClient.type';
import SuccessAlert from './SuccessAlert';
import ErrorAlert from './ErrorAlert';

type UpdateClientModalProps = {
  open: boolean;
  onClose: () => void;
  clientId: number;
  onClientUpdated: (client: ListClientType) => void;
};

const UpdateClientModal: React.FC<UpdateClientModalProps> = ({ open, onClose, clientId, onClientUpdated }) => {
  const [client, setClient] = useState<ListClientType | null>(null);
  const [isFormValid, setIsFormValid] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successAlertOpen, setSuccessAlertOpen] = useState(false);
  const [errorAlertOpen, setErrorAlertOpen] = useState(false);

  useEffect(() => {
    const fetchClientData = async () => {
      setLoading(true);
      setError(null);
      try {
        const clientData: ListClientType = await fetchClientById(clientId);
        setClient(clientData);
      } catch (error) {
        setError('Error loading client data');
      } finally {
        setLoading(false);
      }
    };

    if (open && clientId) {
      fetchClientData();
    }
  }, [clientId, open]);

  useEffect(() => {
    const validateForm = () => {
      return client !== null && client.nit !== '' && client.name !== '' && client.address !== '' && client.city !== '' && client.country !== '' && client.phone !== '' && client.email !== '';
    };
    setIsFormValid(validateForm());
  }, [client]);

  const handleClientChange = (updatedClient: ListClientType) => {
    setClient(updatedClient);
  };

  const handleUpdateClient = async () => {
    if (!isFormValid || isSubmitting) {
      setErrorAlertOpen(true);
      return;
    }

    setIsSubmitting(true); // Evita múltiples clics

    try {
      if (client) {
        const updatedClient = await updateClient(client);
        setSuccessAlertOpen(true);
        onClientUpdated(updatedClient);
        onClose();
      }
    } catch (error) {
      setError('Error updating client');
      setErrorAlertOpen(true);
    } finally {
      setIsSubmitting(false); // Habilita el botón después de completar la operación
    }
  };

  return (
    <>
      <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
        <DialogTitle className="text-center text-2xl font-bold">Update Client</DialogTitle>
        <DialogContent dividers>
          {loading ? (
            <Spinner />
          ) : error ? (
            <ErrorComponent message={error} />
          ) : client ? (
            <ClientForm client={client} onChange={handleClientChange} />
          ) : (
            <p>Error: Client not found</p>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose} color="secondary">
            Cancel
          </Button>
          <Button onClick={handleUpdateClient} color="primary" variant="contained" disabled={!isFormValid || isSubmitting}>
            Update
          </Button>
        </DialogActions>
      </Dialog>

      <SuccessAlert open={successAlertOpen} onClose={() => setSuccessAlertOpen(false)} message="Client updated successfully" />
      <ErrorAlert open={errorAlertOpen} onClose={() => setErrorAlertOpen(false)} message="Please complete all required fields or try again" />
    </>
  );
};

export default UpdateClientModal;
