// components/ClientForm.tsx
import React from 'react';
import { ListClientType } from '../types/ListClient.type';
import { TextField, Box } from '@mui/material';

type ClientFormProps = {
  client: ListClientType;
  onChange: (updatedClient: ListClientType) => void;
  onContactsChange: (contactNames: string[]) => void; // Nueva función para manejar los nombres de contactos
};

const ClientForm: React.FC<ClientFormProps> = ({ client, onChange, onContactsChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onChange({ ...client, [name]: value });
  };

  const handleContactsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const contactNames = e.target.value.split(",").map(name => name.trim());
    onContactsChange(contactNames);
  };

  return (
    <Box component="form" sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <TextField label="NIT" name="nit" type="number" value={client.nit} onChange={handleInputChange} fullWidth required />
      <TextField label="Name" name="name" type="text" value={client.name} onChange={handleInputChange} fullWidth required />
      <TextField label="Address" name="address" type="text" value={client.address} onChange={handleInputChange} fullWidth required />
      <TextField label="City" name="city" type="text" value={client.city} onChange={handleInputChange} fullWidth required />
      <TextField label="Country" name="country" type="text" value={client.country} onChange={handleInputChange} fullWidth required />
      <TextField label="Phone" name="phone" type="tel" value={client.phone} onChange={handleInputChange} fullWidth required />
      <TextField label="Email" name="email" type="email" value={client.email} onChange={handleInputChange} fullWidth required />
      <TextField
        label="Contacts (comma separated names)"
        name="contacts"
        type="text"
        onChange={handleContactsChange}
        fullWidth
        helperText="Enter contact names separated by commas"
      />
    </Box>
  );
};

export default ClientForm;
